#!/usr/bin/env bash
set -e
APP_NAME="OpenMediaShell"
APP_ROOT="$HOME/$APP_NAME"
LEGACY_ROOT="$HOME/OpenTV"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$APP_ROOT/1.2"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/Desktop"
AUTOSTART_DIR="$HOME/.config/autostart"
mkdir -p "$BIN_DIR" "$DESKTOP_DIR" "$AUTOSTART_DIR"
have_cmd(){ command -v "$1" >/dev/null 2>&1; }
install_if_missing(){ local pkg="$1"; shift || true; local cmds=("$@"); for c in "${cmds[@]}"; do if [ -n "$c" ] && have_cmd "$c"; then echo "Skipping $pkg (already installed via command: $c)"; return 0; fi; done; MISSING_PACKAGES+=("$pkg"); }
ensure_google_chrome(){
  if have_cmd google-chrome || have_cmd google-chrome-stable; then
    echo "Google Chrome already installed."
    return 0
  fi
  echo "==> Installing Google Chrome Stable"
  if have_cmd apt; then
    sudo mkdir -p /etc/apt/keyrings
    curl -fsSL https://dl.google.com/linux/linux_signing_key.pub | sudo gpg --dearmor -o /etc/apt/keyrings/google-chrome.gpg
    echo 'deb [arch=amd64 signed-by=/etc/apt/keyrings/google-chrome.gpg] https://dl.google.com/linux/chrome/deb/ stable main' | sudo tee /etc/apt/sources.list.d/google-chrome.list >/dev/null
    sudo apt update
    sudo apt install -y google-chrome-stable
  elif have_cmd dnf; then
    sudo dnf install -y fedora-workstation-repositories || true
    sudo dnf config-manager --set-enabled google-chrome || true
    sudo dnf install -y google-chrome-stable
  elif have_cmd pacman; then
    echo "Automatic Google Chrome Stable installation is not built in for pacman-based systems."
    echo "Install google-chrome from the AUR, then rerun this installer."
    exit 1
  else
    echo "Unsupported package manager for Google Chrome installation."
    exit 1
  fi
}
stop_running(){
  echo "==> Stopping any running $APP_NAME processes"
  pkill -f "node server/app.js" >/dev/null 2>&1 || true
  pkill -f "localhost:3000/tv" >/dev/null 2>&1 || true
  pkill -f "127.0.0.1:3000/tv" >/dev/null 2>&1 || true
  pkill -f "openmediashell-start" >/dev/null 2>&1 || true
  pkill -f "opentv-start" >/dev/null 2>&1 || true
  pkill -x unclutter >/dev/null 2>&1 || true
}
purge_old_install(){
  stop_running
  for OLD_DIR in "$APP_ROOT" "$LEGACY_ROOT"; do
    if [ -d "$OLD_DIR" ]; then
      echo "==> Removing existing install at $OLD_DIR"
      rm -rf "$OLD_DIR"
    fi
  done
  rm -f "$DESKTOP_DIR/OpenTV.desktop" "$DESKTOP_DIR/OpenMediaShell.desktop" "$DESKTOP_DIR/OpenMediaShell 1.2.desktop"
  rm -f "$AUTOSTART_DIR/OpenTV.desktop" "$AUTOSTART_DIR/OpenMediaShell.desktop" "$AUTOSTART_DIR/OpenMediaShell 1.2.desktop"
  rm -f "$BIN_DIR/opentv-start" "$BIN_DIR/opentv-stop" "$BIN_DIR/openmediashell-start" "$BIN_DIR/openmediashell-stop"
  mkdir -p "$TARGET_DIR"
}
install_deps(){
  echo "==> Checking dependencies"
  MISSING_PACKAGES=()
  install_if_missing curl curl
  install_if_missing unzip unzip
  install_if_missing git git
  install_if_missing gnupg gpg
  install_if_missing ca-certificates update-ca-certificates
  install_if_missing python3 python3
  install_if_missing python3-pip pip3
  install_if_missing nodejs node
  install_if_missing npm npm
  install_if_missing xdotool xdotool
  install_if_missing x11-utils xprop
  install_if_missing unclutter unclutter
  install_if_missing wireplumber wpctl
  install_if_missing pulseaudio-utils pactl
  install_if_missing alsa-utils amixer
  install_if_missing kodi kodi
  if [ ${#MISSING_PACKAGES[@]} -eq 0 ]; then
    echo "All base dependencies already satisfied."
  else
    echo "Missing base packages: ${MISSING_PACKAGES[*]}"
    if have_cmd apt; then
      sudo apt update
      sudo apt install -y "${MISSING_PACKAGES[@]}"
    elif have_cmd dnf; then
      sudo dnf install -y "${MISSING_PACKAGES[@]}"
    elif have_cmd pacman; then
      sudo pacman -Sy --noconfirm "${MISSING_PACKAGES[@]}"
    else
      echo "Unsupported package manager."
      exit 1
    fi
  fi
  ensure_google_chrome
}
copy_files(){ echo "==> Copying release files"; rm -rf "$TARGET_DIR"; mkdir -p "$TARGET_DIR"; cp -R "$SRC_DIR"/client "$TARGET_DIR"/; cp -R "$SRC_DIR"/server "$TARGET_DIR"/; cp "$SRC_DIR"/package.json "$TARGET_DIR"/; cp "$SRC_DIR"/package-lock.json "$TARGET_DIR"/ 2>/dev/null || true; cp "$SRC_DIR"/README.md "$TARGET_DIR"/; cp "$SRC_DIR"/APP_PROFILE_PROMPT.md "$TARGET_DIR"/ || true; cp "$SRC_DIR"/CONTEXT_PROMPT_NEXT_CHAT.md "$TARGET_DIR"/ || true; cp "$SRC_DIR"/install_openmediashell.sh "$TARGET_DIR"/; }
npm_install(){ echo "==> Running npm install"; cd "$TARGET_DIR"; npm install; }
write_scripts(){ cat > "$BIN_DIR/openmediashell-start" <<'EOSTART'
#!/usr/bin/env bash
set -e
TARGET_DIR="$HOME/OpenMediaShell/1.2"
SERVER_LOG="$HOME/.openmediashell-server.log"
BROWSER_LOG="$HOME/.openmediashell-browser.log"
PID_FILE="$HOME/.openmediashell-server.pid"
URL="http://localhost:3000/tv"
CHROME_PROFILE_DIR="$HOME/.config/openmediashell/chrome-profile"
SETTINGS_FILE="$TARGET_DIR/server/data/settings.json"
FULLSCREEN_MODE="true"
if [ ! -d "$TARGET_DIR" ]; then
  echo "Installed app folder not found at $TARGET_DIR" >&2
  exit 1
fi
mkdir -p "$CHROME_PROFILE_DIR"
if [ -f "$SETTINGS_FILE" ]; then
  if grep -q '"fullscreen"[[:space:]]*:[[:space:]]*false' "$SETTINGS_FILE"; then
    FULLSCREEN_MODE="false"
  fi
fi
cd "$TARGET_DIR"
if [ -f "$PID_FILE" ]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" >/dev/null 2>&1; then
    kill "$OLD_PID" >/dev/null 2>&1 || true
    sleep 1
  fi
  rm -f "$PID_FILE"
fi
pkill -f "node server/app.js" || true
if [ ! -d node_modules ] || [ ! -f node_modules/qrcode/package.json ]; then
  npm install --omit=dev >> "$SERVER_LOG" 2>&1
fi
nohup env HOST=0.0.0.0 node server/app.js >> "$SERVER_LOG" 2>&1 &
echo $! > "$PID_FILE"
for _ in $(seq 1 30); do
  if curl -fsS http://localhost:3000/api/health >/dev/null 2>&1 || curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1; then
    break
  fi
  sleep 1
done
if ! curl -fsS http://localhost:3000/api/health >/dev/null 2>&1 && ! curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1; then
  echo "OpenMediaShell server failed to start. Check ~/.openmediashell-server.log" >&2
  exit 1
fi
if command -v google-chrome >/dev/null 2>&1; then BROWSER="google-chrome"; elif command -v google-chrome-stable >/dev/null 2>&1; then BROWSER="google-chrome-stable"; elif command -v chromium-browser >/dev/null 2>&1; then BROWSER="chromium-browser"; elif command -v chromium >/dev/null 2>&1; then BROWSER="chromium"; else echo "No supported browser found."; exit 1; fi
pkill -f "localhost:3000/tv" >/dev/null 2>&1 || true
pkill -f "127.0.0.1:3000/tv" >/dev/null 2>&1 || true
BROWSER_ARGS=(--user-data-dir="$CHROME_PROFILE_DIR" --new-window --no-first-run --disable-infobars --app="$URL")
if [ "$FULLSCREEN_MODE" = "true" ]; then
  BROWSER_ARGS=(--user-data-dir="$CHROME_PROFILE_DIR" --kiosk --start-fullscreen --new-window --no-first-run --disable-infobars "$URL")
fi
nohup "$BROWSER" "${BROWSER_ARGS[@]}" >> "$BROWSER_LOG" 2>&1 &
sleep 2
if [ "$FULLSCREEN_MODE" = "true" ] && command -v xdotool >/dev/null 2>&1; then
  for _ in $(seq 1 30); do
    WINDOW_ID="$(xdotool search --onlyvisible --class 'google-chrome|Google-chrome|chromium|Chromium' 2>/dev/null | tail -n 1 || true)"
    if [ -n "$WINDOW_ID" ]; then
      xdotool windowactivate "$WINDOW_ID" >/dev/null 2>&1 || true
      xdotool key --window "$WINDOW_ID" F11 >/dev/null 2>&1 || true
      sleep 0.4
      xdotool key --window "$WINDOW_ID" F11 >/dev/null 2>&1 || true
      break
    fi
    sleep 0.5
  done
fi
disown || true
EOSTART
cat > "$BIN_DIR/openmediashell-stop" <<'EOSTOP'
#!/usr/bin/env bash
PID_FILE="$HOME/.openmediashell-server.pid"
if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$PID" ] && kill -0 "$PID" >/dev/null 2>&1; then
    kill "$PID" >/dev/null 2>&1 || true
  fi
  rm -f "$PID_FILE"
fi
pkill -f "node server/app.js" || true
pkill -f "127.0.0.1:3000/tv" || true
pkill -f "localhost:3000/tv" || true
pkill -x unclutter || true
EOSTOP
chmod +x "$BIN_DIR/openmediashell-start" "$BIN_DIR/openmediashell-stop"; }
write_desktop(){ cat > "$DESKTOP_DIR/OpenMediaShell 1.2.desktop" <<EOF2
[Desktop Entry]
Version=1.0
Type=Application
Name=OpenMediaShell 1.2
Comment=Launch OpenMediaShell 1.2
Exec=/bin/bash -lc "$HOME/.local/bin/openmediashell-start"
Icon=video-display
Terminal=false
Categories=AudioVideo;
Hidden=false
X-GNOME-Autostart-enabled=true
EOF2
chmod +x "$DESKTOP_DIR/OpenMediaShell 1.2.desktop"
cat > "$AUTOSTART_DIR/OpenMediaShell 1.2.desktop" <<EOF3
[Desktop Entry]
Version=1.0
Type=Application
Name=OpenMediaShell 1.2
Comment=Launch OpenMediaShell 1.2 on login
Exec=/bin/bash -lc "$HOME/.local/bin/openmediashell-start"
Icon=video-display
Terminal=false
Categories=AudioVideo;
Hidden=false
X-GNOME-Autostart-enabled=true
EOF3
chmod +x "$AUTOSTART_DIR/OpenMediaShell 1.2.desktop"
}
enable_autologin(){ if [ ! -d /etc/lightdm ]; then echo "LightDM not found. Skipping autologin."; return; fi; USER_NAME="$(whoami)"; sudo mkdir -p /etc/lightdm/lightdm.conf.d; sudo tee /etc/lightdm/lightdm.conf.d/50-openmediashell-autologin.conf >/dev/null <<EOF4
[Seat:*]
autologin-user=$USER_NAME
autologin-user-timeout=0
EOF4
}
install_deps
purge_old_install
copy_files
npm_install
write_scripts
write_desktop
if [ "${OPENMEDIASHELL_AUTO_UPDATE_RUNNING:-0}" != "1" ]; then
  read -r -p "Enable automatic login on LightDM systems? [y/N] " AUTOLOGIN
  if [[ "$AUTOLOGIN" =~ ^[Yy]$ ]]; then enable_autologin; fi
fi
echo
echo "Done."
echo "Desktop launcher created: ~/Desktop/OpenMediaShell 1.2.desktop"
echo "Autostart launcher created: ~/.config/autostart/OpenMediaShell 1.2.desktop"
echo "Run it with: ~/.local/bin/openmediashell-start"
