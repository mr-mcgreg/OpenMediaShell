Project: OpenMediaShell
Current release baseline: OpenMediaShell 1.2.3 with TV-side settings menu and local ZIP update install flow.

Important persistent requirements:
- npm/node processes must fully stop when the app closes
- OpenMediaShell should feel like a polished TV OS shell, not just a plain browser tab
- Main shell should launch in Google Chrome kiosk/fullscreen style, currently via kiosk mode rather than app mode
- New releases should replace older installs cleanly rather than leaving mixed-version leftovers

Current working state:
- one-file-per-app JSON profile system
- Netflix smart-nav works through navigator API
- Remote arrows call navigator jump/nudge for smart-nav apps
- Launcher opens the main TV shell in Chrome kiosk mode with URL /tv
- Home screen now includes a real on-screen Settings modal
- TV settings modal mirrors the main shell controls from the phone settings
- TV settings can upload a local release ZIP with Select ZIP, then run Install update from that selected file
- TV settings also support Update ZIP URL plus Auto update on startup
- Top-right version info badge exists and can be shown/hidden in settings

Files most relevant next:
- client/tv/index.html
- client/remote/index.html
- server/app.js
- server/updater.js
- server/settings.js
- install_openmediashell.sh

Do not restart from scratch. Continue from this packaged release.

Latest patch notes:
- Added a full TV home-screen settings menu instead of only showing phone-only settings hints.
- Added local ZIP upload + selected ZIP install flow from the TV UI.
- Added a show/hide toggle for the top-right version badge.
- Updated README and context to document OpenMediaShell 1.2 behavior.


Patch 1.2.3
- Added a remote Fullscreen button that sends the plain keyboard `f` command for browser players like YouTube and Netflix.

- Remote fullscreen `F` button moved into the D-pad outline to mirror the Back button style.


## Release 1.2 final
- This is the official OpenMediaShell 1.2 release.
- The remote now places Mute inside the D-pad outline as an auxiliary button, alongside Back and F.
- The desktop and autostart launchers now include the installed version in their visible name: OpenMediaShell 1.2.

- Fixed desktop launcher Exec handling so the installed launcher works on systems where .desktop files do not expand $HOME.


Patch note: launcher/server startup was changed to detach the server from the browser process so the shell stays running even if Chrome returns immediately or reuses an existing browser instance.

- Launcher fullscreen behavior hardened by forcing fullscreen after Chrome opens, so it works even when Chrome reuses an existing session.

Patch note: launcher fullscreen now uses a dedicated Chrome profile to avoid existing-session reuse, and the fullscreen fallback targets the actual visible Chrome window instead of only the new process PID.
