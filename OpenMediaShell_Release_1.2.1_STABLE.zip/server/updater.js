const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');
const { saveSettings, getSettings } = require('./settings');

const APP_NAME = 'OpenMediaShell';
const home = os.homedir();
const updateWorkDir = path.join(home, '.openmediashell-updater');
const installScriptName = 'install_openmediashell.sh';
const selectedZipPath = path.join(updateWorkDir, 'selected-update.zip');
let status = {
  inProgress: false,
  lastCheckedAt: null,
  lastAttemptAt: null,
  lastResult: null,
  message: 'No update run yet.',
  selectedZipName: '',
};

function getUpdateStatus(){
  return { ...status, hasSelectedZip: fs.existsSync(selectedZipPath) };
}

function ensureWorkDir(){
  fs.mkdirSync(updateWorkDir, { recursive: true });
}

function runCommand(command, args, options = {}){
  return new Promise((resolve, reject) => {
    const child = execFile(command, args, options, (error, stdout, stderr) => {
      if(error){
        error.stdout = stdout;
        error.stderr = stderr;
        reject(error);
        return;
      }
      resolve({ stdout, stderr });
    });
    if(options.stdio === 'ignore' && child.unref) child.unref();
  });
}

async function checkForConfiguredUpdate(){
  const settings = getSettings();
  status.lastCheckedAt = new Date().toISOString();
  if(!settings.autoUpdateUrl){
    return { ok: false, configured: false, message: 'No update ZIP URL is configured.' };
  }
  return {
    ok: true,
    configured: true,
    autoUpdateEnabled: !!settings.autoUpdateEnabled,
    autoUpdateUrl: settings.autoUpdateUrl,
    message: 'Update source configured.'
  };
}

function saveUploadedZip(buffer, filename = 'selected-update.zip'){
  ensureWorkDir();
  fs.writeFileSync(selectedZipPath, buffer);
  status.selectedZipName = path.basename(filename || 'selected-update.zip');
  status.message = `Selected ZIP: ${status.selectedZipName}`;
  status.lastResult = 'selected';
  return { ok: true, selectedZipName: status.selectedZipName, status: getUpdateStatus() };
}

function clearSelectedZip(){
  fs.rmSync(selectedZipPath, { force: true });
  status.selectedZipName = '';
  if(status.message.startsWith('Selected ZIP:')) status.message = 'No update run yet.';
  return { ok: true, status: getUpdateStatus() };
}

async function launchInstallerFromZip(zipPath, sourceLabel){
  ensureWorkDir();
  const extractDir = path.join(updateWorkDir, 'release');
  fs.rmSync(extractDir, { recursive: true, force: true });
  fs.mkdirSync(extractDir, { recursive: true });
  await runCommand('unzip', ['-o', zipPath, '-d', extractDir]);

  const candidatePaths = [
    path.join(extractDir, installScriptName),
    path.join(extractDir, 'install_opentv.sh'),
  ];

  let installScript = candidatePaths.find(fs.existsSync);
  if(!installScript){
    const entries = fs.readdirSync(extractDir, { withFileTypes: true });
    for(const entry of entries){
      if(!entry.isDirectory()) continue;
      const nested = candidatePaths
        .map(candidate => path.join(extractDir, entry.name, path.basename(candidate)))
        .find(fs.existsSync);
      if(nested){
        installScript = nested;
        break;
      }
    }
  }

  if(!installScript){
    throw new Error('Selected ZIP does not contain an installer script.');
  }

  fs.chmodSync(installScript, 0o755);
  const detached = execFile('bash', [installScript], {
    cwd: path.dirname(installScript),
    detached: true,
    stdio: 'ignore',
    env: {
      ...process.env,
      OPENMEDIASHELL_AUTO_UPDATE_RUNNING: '1',
    },
  });
  detached.unref();
  status.lastResult = 'success';
  status.message = `Update installer launched from ${sourceLabel}. The new release should replace the current install.`;
}

async function performUpdate({ manual = false, source = 'url' } = {}){
  const settings = getSettings();
  status.lastAttemptAt = new Date().toISOString();
  if(status.inProgress){
    return { ok: false, message: 'An update is already running.', status: getUpdateStatus() };
  }
  status.inProgress = true;
  status.message = manual ? 'Running manual update…' : 'Running automatic update…';
  try{
    ensureWorkDir();
    let zipPath = '';
    let sourceLabel = 'ZIP URL';

    if(source === 'selected'){
      if(!fs.existsSync(selectedZipPath)) throw new Error('No ZIP has been selected yet.');
      zipPath = selectedZipPath;
      sourceLabel = status.selectedZipName || 'selected ZIP';
    }else{
      if(!settings.autoUpdateUrl){
        status.lastResult = 'error';
        status.message = 'Update URL is empty.';
        return { ok: false, message: status.message, status: getUpdateStatus() };
      }
      zipPath = path.join(updateWorkDir, 'release.zip');
      await runCommand('curl', ['-L', '--fail', '--output', zipPath, settings.autoUpdateUrl]);
      sourceLabel = settings.autoUpdateUrl;
    }

    await launchInstallerFromZip(zipPath, sourceLabel);
    saveSettings({ lastUpdateSource: source === 'selected' ? (status.selectedZipName || 'selected ZIP') : settings.autoUpdateUrl });
    return { ok: true, message: status.message, status: getUpdateStatus() };
  }catch(error){
    status.lastResult = 'error';
    status.message = error.message || 'Update failed.';
    return { ok: false, message: status.message, status: getUpdateStatus() };
  }finally{
    status.inProgress = false;
  }
}

async function maybeAutoUpdateOnStartup(){
  const settings = getSettings();
  if(!settings.autoUpdateEnabled || !settings.autoUpdateUrl || process.env.OPENMEDIASHELL_AUTO_UPDATE_RUNNING === '1'){
    return;
  }
  return performUpdate({ manual: false, source: 'url' });
}

module.exports = {
  getUpdateStatus,
  checkForConfiguredUpdate,
  performUpdate,
  maybeAutoUpdateOnStartup,
  saveUploadedZip,
  clearSelectedZip,
};
