const os = require('os');
const path = require('path');
const express = require('express');
const QRCode = require('qrcode');
const { Server } = require('socket.io');
const { createServer } = require('http');
const { handleAction, handleMouseMove, handleTextInput, getState, launchApp } = require('./actions');
const { getApps } = require('./apps/registry');
const { getSettings, saveSettings, setAutostartEnabled } = require('./settings');
const { getRandomBackgroundInfo } = require('./backgrounds');
const { pickFolder } = require('./adapters/x11');
const { listProfiles, getNavigatorState, enableNavigator, disableNavigator, refreshNavigatorDisplay, jumpNavigator, nudgeNavigator, resetNavigatorAnchor, setNavigatorAnchor } = require('./navigator');
const { getUpdateStatus, checkForConfiguredUpdate, performUpdate, maybeAutoUpdateOnStartup, saveUploadedZip, clearSelectedZip } = require('./updater');

const APP_NAME = 'OpenMediaShell';
const APP_VERSION = '1.2.0';
const HOST = process.env.HOST || '0.0.0.0';
const PORT = Number(process.env.PORT || 3000);
const app = express();
const server = createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

function getLanIp(){
  const nets = os.networkInterfaces();
  for(const name of Object.keys(nets)){
    for(const net of nets[name] || []){
      if(net.family === 'IPv4' && !net.internal) return net.address;
    }
  }
  return '127.0.0.1';
}
function remoteUrl(){ return `http://${getLanIp()}:${PORT}/remote`; }
function broadcastSettings(){ io.emit('settings:update', getSettings()); }
function broadcastUpdate(){ io.emit('update:status', getUpdateStatus()); }

app.use(express.json({ limit: '20mb' }));
app.use('/remote', express.static(path.join(__dirname,'..','client','remote')));
app.use('/tv-assets', express.static(path.join(__dirname,'..','client','tv')));
app.use('/assets', express.static(path.join(__dirname,'..','client','assets')));
app.get('/', (_req,res)=>res.redirect('/tv'));
app.get('/tv', (_req,res)=>res.sendFile(path.join(__dirname,'..','client','tv','index.html')));
app.get('/remote', (_req,res)=>res.sendFile(path.join(__dirname,'..','client','remote','index.html')));
app.get('/api/health', (_req,res)=>res.json({ok:true, service:APP_NAME, version:APP_VERSION}));
app.get('/api/config', async (_req,res)=>{
  const url = remoteUrl();
  const qrDataUrl = await QRCode.toDataURL(url,{margin:1,width:220});
  res.json({
    appName: APP_NAME,
    version: APP_VERSION,
    remoteUrl: url,
    qrDataUrl,
    settings: getSettings(),
    updateStatus: getUpdateStatus(),
    state: getState(),
    navigator: getNavigatorState(),
    apps: getApps()
  });
});
app.get('/api/backgrounds/current', (_req,res)=>{
  const info = getRandomBackgroundInfo();
  if(info.type === 'online') return res.redirect(info.url);
  res.sendFile(info.path);
});
app.get('/api/settings', (_req,res)=>res.json({ok:true, settings:getSettings(), updateStatus:getUpdateStatus()}));
app.post('/api/settings', async (req,res)=>{
  try{
    const body = req.body || {};
    const next = {};
    if(typeof body.fullscreen === 'boolean') next.fullscreen = body.fullscreen;
    if(typeof body.showQR === 'boolean') next.showQR = body.showQR;
    if(typeof body.showTopRightInfo === 'boolean') next.showTopRightInfo = body.showTopRightInfo;
    if(typeof body.onlineBackgroundUrl === 'string') next.onlineBackgroundUrl = body.onlineBackgroundUrl;
    if(typeof body.backgroundFolder === 'string') next.backgroundFolder = body.backgroundFolder;
    if(typeof body.autoUpdateEnabled === 'boolean') next.autoUpdateEnabled = body.autoUpdateEnabled;
    if(typeof body.autoUpdateUrl === 'string') next.autoUpdateUrl = body.autoUpdateUrl.trim();
    if(typeof body.launchOnStartup === 'boolean'){
      const auto = setAutostartEnabled(body.launchOnStartup);
      if(!auto.ok) return res.status(400).json(auto);
      next.launchOnStartup = body.launchOnStartup;
    }
    const settings = saveSettings(next);
    broadcastSettings();
    res.json({ok:true, settings, updateStatus:getUpdateStatus()});
  }catch(error){
    res.status(500).json({ok:false,message:error.message});
  }
});
app.post('/api/settings/pick-background-folder', async (_req,res)=>{
  try{
    const folder = await pickFolder();
    const settings = saveSettings({backgroundFolder:folder||''});
    broadcastSettings();
    res.json({ok:true, settings, selectedFolder: folder||''});
  }catch(error){
    res.status(500).json({ok:false,message:error.message});
  }
});

app.get('/api/update/status', async (_req,res)=>{
  const check = await checkForConfiguredUpdate();
  res.json({ok:true, check, status:getUpdateStatus(), settings:getSettings()});
});
app.post('/api/update/run', async (req,res)=>{
  const source = String((req.body||{}).source || 'url');
  const result = await performUpdate({ manual: true, source });
  broadcastUpdate();
  if(result.ok){
    res.json(result);
    setTimeout(()=>process.exit(0), 300);
    return;
  }
  res.status(400).json(result);
});
app.post('/api/update/upload', express.raw({ type: '*/*', limit: '3gb' }), async (req,res)=>{
  try{
    if(!req.body || !req.body.length) return res.status(400).json({ok:false,message:'No ZIP file received.'});
    const filename = String(req.headers['x-file-name'] || 'selected-update.zip');
    const result = saveUploadedZip(req.body, filename);
    broadcastUpdate();
    res.json(result);
  }catch(error){
    res.status(500).json({ok:false,message:error.message});
  }
});
app.post('/api/update/clear-selected', (_req,res)=>{
  const result = clearSelectedZip();
  broadcastUpdate();
  res.json(result);
});

app.get('/api/navigator', async (_req,res)=>{
  try{
    await refreshNavigatorDisplay();
    res.json({ok:true, state:getNavigatorState(), profiles:listProfiles()});
  }catch(error){ res.status(500).json({ok:false,message:error.message}); }
});
app.post('/api/navigator/enable/:profileId', async (req,res)=>{
  try{ const state = await enableNavigator(String(req.params.profileId||'')); res.json({ok:true, state}); }catch(error){ res.status(400).json({ok:false,message:error.message}); }
});
app.post('/api/navigator/disable', (_req,res)=>{ try{ const state = disableNavigator(); res.json({ok:true, state}); }catch(error){ res.status(500).json({ok:false,message:error.message}); } });
app.post('/api/navigator/jump/:direction', async (req,res)=>{
  try{ const state = await jumpNavigator(String(req.params.direction||'')); res.json({ok:true, state}); }catch(error){ res.status(400).json({ok:false,message:error.message}); }
});
app.post('/api/navigator/nudge', async (req,res)=>{
  try{ const body=req.body||{}; const state=await nudgeNavigator(Number(body.dx||0), Number(body.dy||0)); res.json({ok:true, state}); }catch(error){ res.status(400).json({ok:false,message:error.message}); }
});
app.post('/api/navigator/reset-anchor', async (_req,res)=>{
  try{ const point=await resetNavigatorAnchor(); res.json({ok:true, anchor:point, state:getNavigatorState()}); }catch(error){ res.status(400).json({ok:false,message:error.message}); }
});
app.post('/api/navigator/set-anchor', async (_req,res)=>{
  try{ const state=await setNavigatorAnchor(); res.json({ok:true, state}); }catch(error){ res.status(400).json({ok:false,message:error.message}); }
});

app.get('/api/apps', (_req,res)=>{ try{ res.json({ok:true, apps:getApps()}); }catch(error){ res.status(500).json({ok:false,message:error.message}); } });
app.post('/api/apps/:appId/launch', async (req,res)=>{ try{ const result=await launchApp(String(req.params.appId||'')); io.emit('server:state', getState()); res.json(result); }catch(error){ res.status(400).json({ok:false,message:error.message}); } });

io.on('connection', socket=>{
  socket.emit('server:state', getState());
  socket.emit('settings:update', getSettings());
  socket.emit('update:status', getUpdateStatus());
  socket.on('remote:press', async (payload={},ack)=>{
    const action = String(payload.action||'').trim();
    if(!action){
      const result={ok:false,message:'Missing action.'};
      if(ack) ack(result);
      socket.emit('server:result', result);
      return;
    }
    try{
      const result=await handleAction(action,{io});
      io.emit('server:state', getState());
      socket.emit('server:result', result);
      if(ack) ack(result);
    }catch(error){
      const result={ok:false,action,message:error.message};
      socket.emit('server:result', result);
      if(ack) ack(result);
    }
  });
  socket.on('remote:mouse_move', async (payload={},ack)=>{
    try{ const result=await handleMouseMove(Number(payload.dx||0), Number(payload.dy||0)); if(ack) ack(result); }
    catch(error){ const result={ok:false,message:error.message}; if(ack) ack(result); }
  });
  socket.on('remote:type', async (payload={},ack)=>{
    try{ const result=await handleTextInput(String(payload.text||''), Boolean(payload.submit)); io.emit('server:state', getState()); socket.emit('server:result', result); if(ack) ack(result); }
    catch(error){ const result={ok:false,message:error.message}; socket.emit('server:result', result); if(ack) ack(result); }
  });
});

server.listen(PORT, HOST, async ()=>{
  console.log(`${APP_NAME} ${APP_VERSION} listening on http://${HOST}:${PORT}`);
  console.log(`Phone remote URL: ${remoteUrl()}`);
  const autoResult = await maybeAutoUpdateOnStartup();
  if(autoResult) console.log(autoResult.message || 'Automatic update check finished.');
});
