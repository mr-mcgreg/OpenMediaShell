# OpenMediaShell 1.2.3

OpenMediaShell 1.2 is a modular remote-first launcher for Chrome-based streaming apps and Kodi on Linux.

## What changed in 1.2
- TV home screen now has a full on-screen **Settings** menu, not just a status panel
- TV settings mirror the core phone settings options
- You can now **select a local release ZIP** from the TV UI and run **Install update** from the home menu
- The updater still supports a network **Update ZIP URL** for startup and manual URL-based updates
- The top-right version badge can now be shown or hidden in settings
- README and context were updated to treat this as the current packaged baseline

## Existing shell features carried forward
- One JSON file per app under `server/apps/profiles/`
- TV home screen builds itself from app profiles
- Remote quick-launch buttons build themselves from app profiles
- Launch, focus, fullscreen, and close behavior come from app profiles
- Google Chrome Stable is the preferred browser for DRM-capable web streaming apps
- Navigator data lives inside the same app profile file
- Includes a reusable AI prompt at `APP_PROFILE_PROMPT.md`

## Built-in app profiles
- `netflix.json`
- `youtube.json`
- `kodi.json`
- `_template.json` for creating new apps

## App profile location
`server/apps/profiles/`

## Install
```bash
chmod +x install_openmediashell.sh
./install_openmediashell.sh
```

## Update paths
### From the TV home menu
1. Open **Settings** from the home tile
2. For a local file update, press **Select ZIP**
3. Pick the new release ZIP
4. Press **Install update**

### From a hosted release ZIP
1. Open **Settings**
2. Paste the newest release ZIP into **Update ZIP URL**
3. Press **Install URL update** or enable **Auto update on startup**

## Notes
- Web apps launch in Google Chrome Stable when available
- Kodi remains a desktop app
- The installer purges older OpenTV/OpenMediaShell installs before reinstalling
- The installer ensures Node.js, npm, and a direct `npm install` are run during setup
- The installed launcher starts the Node server directly instead of relying on `npm start`


Patch 1.2.3
- Added a remote Fullscreen button that sends the plain keyboard `f` command for browser players like YouTube and Netflix.

- Remote fullscreen `F` button moved into the D-pad outline to mirror the Back button style.


## Release 1.2 final
- This is the official OpenMediaShell 1.2 release.
- The remote now places Mute inside the D-pad outline as an auxiliary button, alongside Back and F.
- The desktop and autostart launchers now include the installed version in their visible name: OpenMediaShell 1.2.

- Fixed desktop launcher Exec handling so the installed launcher works on systems where .desktop files do not expand $HOME.


Patch note: launcher/server startup was changed to detach the server from the browser process so the shell stays running even if Chrome returns immediately or reuses an existing browser instance.

- Launcher fullscreen behavior hardened by forcing fullscreen after Chrome opens, so it works even when Chrome reuses an existing session.

Patch note: launcher fullscreen now uses a dedicated Chrome profile to avoid existing-session reuse, and the fullscreen fallback targets the actual visible Chrome window instead of only the new process PID.
