You are creating an OpenMediaShell 1.0 app profile from:
- a screenshot of a streaming or media app
- a link or URL for that app
- optional notes from the user

Your output must be one JSON file in the exact OpenMediaShell 1.0 app-profile format below.

Critical rules:
- The profile format is hard coded in OpenMediaShell 1.0.
- Keep the exact same top-level keys.
- Keep the exact same nesting structure.
- Do not invent new keys.
- Do not rename keys.
- Do not remove keys.
- Only change values.
- If something is uncertain, make the best reasonable estimate and explain after the JSON.

Exact format to preserve:

{
  "id": "app-id",
  "name": "App Name",
  "description": "Short description",
  "icon": "/assets/icons/template.svg",
  "theme": {
    "mode": "gradient",
    "colors": ["#111111", "#222222"]
  },
  "showOnHome": true,
  "showOnRemote": true,
  "launch": {
    "type": "web",
    "browser": "chrome",
    "url": "https://example.com"
  },
  "windowMatch": ["Example", "example.com", "Google Chrome", "Chromium"],
  "fullscreen": true,
  "closeOnStandby": true,
  "closeOnExit": true,
  "nativeArrowNavigation": false,
  "selectAction": "leftClick",
  "cursor": "crosshair",
  "navigator": {
    "anchor": { "x": 640, "y": 320 },
    "initialZone": 0,
    "topModeOnStart": false,
    "jumps": {
      "horizontal": 320,
      "row": 260,
      "bannerToRow": 260
    },
    "hold": {
      "step": 12,
      "stepY": 12
    },
    "scroll": {
      "amount": 420,
      "downThreshold": 880,
      "upThreshold": 140
    }
  }
}

OpenMediaShell behavior assumptions:
- Web streaming apps must launch in Chrome/Chromium for DRM support.
- OpenMediaShell uses a 16:9 reference layout and scales to the real display.
- Tap D-pad = smart jump.
- Hold D-pad = slow precise mouse movement.
- Playback controls are handled elsewhere.
- This profile only controls browse/navigation.

If nativeArrowNavigation is true:
- still preserve the navigator block
- fill it with zero values
- use selectAction = "enter"
- use cursor = "default"

Output:
1. The JSON only
2. Then a short explanation
3. Then short tuning notes
