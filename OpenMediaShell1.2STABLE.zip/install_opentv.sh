#!/usr/bin/env bash
set -e
APP_ROOT="$HOME/OpenTV"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$APP_ROOT/1.0"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/Desktop"
AUTOSTART_DIR="$HOME/.config/autostart"
mkdir -p "$BIN_DIR" "$DESKTOP_DIR" "$AUTOSTART_DIR"
have_cmd(){ command -v "$1" >/dev/null 2>&1; }
install_if_missing(){ local pkg="$1"; shift || true; local cmds=("$@"); for c in "${cmds[@]}"; do if [ -n "$c" ] && have_cmd "$c"; then echo "Skipping $pkg (already installed via command: $c)"; return 0; fi; done; MISSING_PACKAGES+=("$pkg"); }
ensure_google_chrome(){
  if have_cmd google-chrome || have_cmd google-chrome-stable; then
    echo "Google Chrome already installed."
    return 0
  fi
  echo "==> Installing Google Chrome Stable"
  if have_cmd apt; then
    sudo mkdir -p /etc/apt/keyrings
    curl -fsSL https://dl.google.com/linux/linux_signing_key.pub | sudo gpg --dearmor -o /etc/apt/keyrings/google-chrome.gpg
    echo 'deb [arch=amd64 signed-by=/etc/apt/keyrings/google-chrome.gpg] https://dl.google.com/linux/chrome/deb/ stable main' | sudo tee /etc/apt/sources.list.d/google-chrome.list >/dev/null
    sudo apt update
    sudo apt install -y google-chrome-stable
  elif have_cmd dnf; then
    sudo dnf install -y fedora-workstation-repositories || true
    sudo dnf config-manager --set-enabled google-chrome || true
    sudo dnf install -y google-chrome-stable
  elif have_cmd pacman; then
    echo "Automatic Google Chrome Stable installation is not built in for pacman-based systems."
    echo "Install google-chrome from the AUR, then rerun this installer."
    exit 1
  else
    echo "Unsupported package manager for Google Chrome installation."
    exit 1
  fi
}
stop_running_opentv(){
  echo "==> Stopping any running OpenTV processes"
  pkill -f "node server/app.js" >/dev/null 2>&1 || true
  pkill -f "localhost:3000/tv" >/dev/null 2>&1 || true
  pkill -f "127.0.0.1:3000/tv" >/dev/null 2>&1 || true
  pkill -x unclutter >/dev/null 2>&1 || true
}
purge_old_install(){
  stop_running_opentv
  if [ -d "$APP_ROOT" ]; then
    echo "==> Removing existing OpenTV install at $APP_ROOT"
    rm -rf "$APP_ROOT"
  fi
  mkdir -p "$TARGET_DIR"
}
install_deps(){
  echo "==> Checking dependencies"
  MISSING_PACKAGES=()
  install_if_missing curl curl
  install_if_missing git git
  install_if_missing gnupg gpg
  install_if_missing ca-certificates update-ca-certificates
  install_if_missing python3 python3
  install_if_missing python3-pip pip3
  install_if_missing nodejs node
  install_if_missing npm npm
  install_if_missing xdotool xdotool
  install_if_missing x11-utils xprop
  install_if_missing unclutter unclutter
  install_if_missing wireplumber wpctl
  install_if_missing pulseaudio-utils pactl
  install_if_missing alsa-utils amixer
  install_if_missing kodi kodi
  if [ ${#MISSING_PACKAGES[@]} -eq 0 ]; then
    echo "All base dependencies already satisfied."
  else
    echo "Missing base packages: ${MISSING_PACKAGES[*]}"
    if have_cmd apt; then
      sudo apt update
      sudo apt install -y "${MISSING_PACKAGES[@]}"
    elif have_cmd dnf; then
      sudo dnf install -y "${MISSING_PACKAGES[@]}"
    elif have_cmd pacman; then
      sudo pacman -Sy --noconfirm "${MISSING_PACKAGES[@]}"
    else
      echo "Unsupported package manager."
      exit 1
    fi
  fi
  ensure_google_chrome
}
copy_files(){ echo "==> Copying release files"; rm -rf "$TARGET_DIR"; mkdir -p "$TARGET_DIR"; cp -R "$SRC_DIR"/client "$TARGET_DIR"/; cp -R "$SRC_DIR"/server "$TARGET_DIR"/; cp "$SRC_DIR"/package.json "$TARGET_DIR"/; cp "$SRC_DIR"/package-lock.json "$TARGET_DIR"/ 2>/dev/null || true; cp "$SRC_DIR"/README.md "$TARGET_DIR"/; cp "$SRC_DIR"/APP_PROFILE_PROMPT.md "$TARGET_DIR"/ || true; cp "$SRC_DIR"/CONTEXT_PROMPT_NEXT_CHAT.md "$TARGET_DIR"/ || true; }
npm_install(){
  echo "==> Running npm install"
  cd "$TARGET_DIR"
  npm install
}
write_scripts(){ cat > "$BIN_DIR/opentv-start" <<'EOSTART'
#!/usr/bin/env bash
set -e
TARGET_DIR="$HOME/OpenTV/1.0"
SERVER_LOG="$HOME/.opentv-server.log"
BROWSER_LOG="$HOME/.opentv-browser.log"
URL="http://localhost:3000/tv"
cd "$TARGET_DIR"
pkill -f "node server/app.js" || true
if [ ! -d node_modules ] || [ ! -f node_modules/qrcode/package.json ]; then
  npm install --omit=dev >> "$SERVER_LOG" 2>&1
fi
HOST=0.0.0.0 node server/app.js > "$SERVER_LOG" 2>&1 &
SERVER_PID=$!
cleanup(){ kill "$SERVER_PID" >/dev/null 2>&1 || true; pkill -x unclutter >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM
for _ in $(seq 1 30); do
  if curl -fsS http://localhost:3000/api/health >/dev/null 2>&1 || curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1; then
    break
  fi
  sleep 1
done
if ! curl -fsS http://localhost:3000/api/health >/dev/null 2>&1 && ! curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1; then
  echo "OpenTV server failed to start. Check ~/.opentv-server.log" >&2
  exit 1
fi
if command -v google-chrome >/dev/null 2>&1; then BROWSER="google-chrome"; elif command -v google-chrome-stable >/dev/null 2>&1; then BROWSER="google-chrome-stable"; elif command -v chromium-browser >/dev/null 2>&1; then BROWSER="chromium-browser"; elif command -v chromium >/dev/null 2>&1; then BROWSER="chromium"; else echo "No supported browser found."; exit 1; fi
pkill -f "localhost:3000/tv" >/dev/null 2>&1 || true
pkill -f "127.0.0.1:3000/tv" >/dev/null 2>&1 || true
"$BROWSER" --kiosk --new-window --no-first-run --disable-infobars "$URL" > "$BROWSER_LOG" 2>&1
EOSTART
cat > "$BIN_DIR/opentv-stop" <<'EOSTOP'
#!/usr/bin/env bash
pkill -f "node server/app.js" || true
pkill -f "127.0.0.1:3000/tv" || true
pkill -x unclutter || true
EOSTOP
chmod +x "$BIN_DIR/opentv-start" "$BIN_DIR/opentv-stop"; }
write_desktop(){ cat > "$DESKTOP_DIR/OpenTV.desktop" <<EOF2
[Desktop Entry]
Version=1.0
Type=Application
Name=OpenTV
Comment=Launch OpenTV
Exec=$HOME/.local/bin/opentv-start
Icon=video-display
Terminal=false
Categories=AudioVideo;
Hidden=false
EOF2
chmod +x "$DESKTOP_DIR/OpenTV.desktop"
rm -f "$AUTOSTART_DIR/OpenTV.desktop"
}
enable_autologin(){ if [ ! -d /etc/lightdm ]; then echo "LightDM not found. Skipping autologin."; return; fi; USER_NAME="$(whoami)"; sudo mkdir -p /etc/lightdm/lightdm.conf.d; sudo tee /etc/lightdm/lightdm.conf.d/50-opentv-autologin.conf >/dev/null <<EOF4
[Seat:*]
autologin-user=$USER_NAME
autologin-user-timeout=0
EOF4
}
install_deps
purge_old_install
copy_files
npm_install
write_scripts
write_desktop
read -r -p "Enable automatic login on LightDM systems? [y/N] " AUTOLOGIN
if [[ "$AUTOLOGIN" =~ ^[Yy]$ ]]; then enable_autologin; fi
echo
echo "Done."
echo "Desktop launcher created: ~/Desktop/OpenTV.desktop"
echo "Autostart is not enabled by default in this release."
echo "Run it with: ~/.local/bin/opentv-start"
