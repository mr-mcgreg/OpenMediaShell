const fs = require('fs');
const path = require('path');
const { getSettings } = require('./settings');
const IMAGE_EXTS = new Set(['.jpg','.jpeg','.png','.webp']);
function listLocalImages(folderPath){
  if(!folderPath) return [];
  try{
    return fs.readdirSync(folderPath,{withFileTypes:true})
      .filter(e=>e.isFile())
      .map(e=>path.join(folderPath,e.name))
      .filter(f=>IMAGE_EXTS.has(path.extname(f).toLowerCase()));
  }catch{ return []; }
}
function getRandomBackgroundInfo(){
  const settings = getSettings();
  const imgs = listLocalImages(settings.backgroundFolder);
  if(imgs.length) return {type:'local', path: imgs[Math.floor(Math.random()*imgs.length)]};
  return {type:'online', url: settings.onlineBackgroundUrl};
}
module.exports = { getRandomBackgroundInfo };
