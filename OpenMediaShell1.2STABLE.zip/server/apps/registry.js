const fs = require('fs');
const path = require('path');

const APPS_DIR = path.join(__dirname, 'profiles');

function parseJson(filePath){
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function normalizeApp(app){
  return {
    id: String(app.id || '').trim(),
    name: String(app.name || '').trim(),
    description: String(app.description || '').trim(),
    icon: String(app.icon || '/assets/icons/default.svg'),
    theme: {
      mode: app.theme?.mode || 'gradient',
      colors: Array.isArray(app.theme?.colors) ? app.theme.colors.slice(0,2) : ['#2b2b2b','#111111']
    },
    showOnHome: Boolean(app.showOnHome),
    showOnRemote: Boolean(app.showOnRemote),
    launch: {
      type: app.launch?.type || 'web',
      browser: app.launch?.browser || 'chrome',
      url: app.launch?.url || '',
      command: app.launch?.command || ''
    },
    windowMatch: Array.isArray(app.windowMatch) ? app.windowMatch : [],
    fullscreen: app.fullscreen !== false,
    closeOnStandby: app.closeOnStandby !== false,
    closeOnExit: app.closeOnExit !== false,
    nativeArrowNavigation: Boolean(app.nativeArrowNavigation),
    selectAction: app.selectAction || 'leftClick',
    cursor: app.cursor || 'default',
    navigator: app.navigator || {
      anchor: { x: 0, y: 0 },
      initialZone: 0,
      topModeOnStart: false,
      jumps: { horizontal: 0, row: 0, bannerToRow: 0 },
      hold: { step: 0, stepY: 0 },
      scroll: { amount: 0, downThreshold: 0, upThreshold: 0 }
    }
  };
}

function validateApp(app, filePath){
  const missing = [];
  for(const key of ['id','name']) if(!app[key]) missing.push(key);
  if(!app.launch || !app.launch.type) missing.push('launch.type');
  if(app.launch?.type === 'web' && !app.launch?.url) missing.push('launch.url');
  if(app.launch?.type === 'desktop' && !app.launch?.command) missing.push('launch.command');
  if(missing.length) throw new Error(`Invalid app profile ${path.basename(filePath)} missing: ${missing.join(', ')}`);
}

function listAppFiles(){
  if(!fs.existsSync(APPS_DIR)) return [];
  return fs.readdirSync(APPS_DIR)
    .filter(name => name.endsWith('.json') && !name.startsWith('_'))
    .map(name => path.join(APPS_DIR, name))
    .sort();
}

function loadApps(){
  const apps = listAppFiles().map(filePath => {
    const app = normalizeApp(parseJson(filePath));
    validateApp(app, filePath);
    return app;
  });
  return apps;
}

function getApps(){
  return loadApps();
}

function getAppById(id){
  const app = loadApps().find(item => item.id === id);
  if(!app) throw new Error(`App profile not found: ${id}`);
  return app;
}

function getClosableApps(){
  return loadApps().filter(app => app.closeOnStandby || app.closeOnExit);
}

module.exports = {
  APPS_DIR,
  getApps,
  getAppById,
  getClosableApps
};
