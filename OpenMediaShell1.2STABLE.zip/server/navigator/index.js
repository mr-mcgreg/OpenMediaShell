const path = require('path');
const { NavigatorCore, NavigatorProfileLoader } = require('./core');
const adapter = require('../adapters/x11');

const loader = new NavigatorProfileLoader(path.join(__dirname, 'profiles'));
const core = new NavigatorCore(adapter, loader);

module.exports = {
  listProfiles: () => loader.listProfiles(),
  getProfile: (id) => loader.getProfile(id),
  enableNavigator: (id) => core.enable(id),
  enableNavigatorProfile: (profile) => core.enableProfile(profile),
  disableNavigator: () => core.disable(),
  getNavigatorState: () => core.getState(),
  refreshNavigatorDisplay: () => core.refreshDisplay(),
  jumpNavigator: (direction) => core.jump(direction),
  nudgeNavigator: (dx, dy) => core.recordFineMove(dx, dy),
  resetNavigatorAnchor: () => core.moveToAnchor(),
  setNavigatorAnchor: () => core.setManualAnchor()
};
