const fs = require('fs');
const path = require('path');

const BASE_WIDTH = 1920;
const BASE_HEIGHT = 1080;
const ASPECT_WIDTH = 16;
const ASPECT_HEIGHT = 9;

function clamp(value, min, max){ return Math.max(min, Math.min(max, value)); }

class NavigatorCore {
  constructor(adapter, profileLoader){
    this.adapter = adapter;
    this.profileLoader = profileLoader;
    this.state = this.createInitialState();
    this.idleReturnTimer = null;
    this.pendingReturnPoint = null;
  }

  createInitialState(){
    return {
      enabled: false,
      activeProfileId: null,
      activeProfileName: null,
      display: null,
      viewport: null,
      laneX: null,
      currentZone: 0,
      topMode: false,
      anchor: null,
      lastJump: null,
      profileState: {}
    };
  }

  async refreshDisplay(){
    const display = await this.adapter.getDisplayInfo();
    const viewport = this.computeViewport(display.width, display.height);
    this.state.display = display;
    this.state.viewport = viewport;
    return { display, viewport };
  }

  computeViewport(width, height){
    const displayAspect = width / height;
    const targetAspect = ASPECT_WIDTH / ASPECT_HEIGHT;
    let viewportWidth = width;
    let viewportHeight = height;
    let offsetX = 0;
    let offsetY = 0;

    if(displayAspect > targetAspect){
      viewportHeight = height;
      viewportWidth = Math.round(height * targetAspect);
      offsetX = Math.round((width - viewportWidth) / 2);
    }else if(displayAspect < targetAspect){
      viewportWidth = width;
      viewportHeight = Math.round(width / targetAspect);
      offsetY = Math.round((height - viewportHeight) / 2);
    }

    return {
      x: offsetX,
      y: offsetY,
      width: viewportWidth,
      height: viewportHeight,
      scaleX: viewportWidth / BASE_WIDTH,
      scaleY: viewportHeight / BASE_HEIGHT,
      aspectRatio: `${ASPECT_WIDTH}:${ASPECT_HEIGHT}`,
      baseWidth: BASE_WIDTH,
      baseHeight: BASE_HEIGHT
    };
  }

  scaleX(value){ return Math.round(value * (this.state.viewport?.scaleX || 1)); }
  scaleY(value){ return Math.round(value * (this.state.viewport?.scaleY || 1)); }


  clearIdleReturn(){
    if(this.idleReturnTimer){
      clearTimeout(this.idleReturnTimer);
      this.idleReturnTimer = null;
    }
    this.pendingReturnPoint = null;
  }

  scheduleIdleReturn(point){
    this.clearIdleReturn();
    this.pendingReturnPoint = { x: point.x, y: point.y, profileId: this.state.activeProfileId };
    this.idleReturnTimer = setTimeout(async()=>{
      const target = this.pendingReturnPoint;
      this.idleReturnTimer = null;
      if(!target || !this.state.enabled || target.profileId !== this.state.activeProfileId) return;
      try{
        const clamped = this.clampToViewport(target.x, target.y);
        await this.adapter.moveMouseAbsolute(clamped.x, clamped.y);
        this.state.lastJump = { type: 'idle-reset', x: clamped.x, y: clamped.y, zone: this.state.currentZone };
      }catch{}
      this.pendingReturnPoint = null;
    }, 4000);
  }

  async enable(profileId){
    const profile = this.profileLoader.getProfile(profileId);
    return this.enableProfile(profile);
  }

  async enableProfile(profile){
    await this.refreshDisplay();
    this.clearIdleReturn();
    this.state.enabled = true;
    this.state.activeProfileId = profile.id;
    this.state.activeProfileName = profile.name;
    this.state.profileState = {};
    this.state.currentZone = Number(profile.navigator?.initialZone || 0);
    this.state.topMode = Boolean(profile.navigator?.topModeOnStart);
    await this.moveToAnchor(profile, true);
    return this.getState();
  }

  disable(){
    this.clearIdleReturn();
    this.state = this.createInitialState();
    return this.getState();
  }

  getProfile(){
    return this.state.activeProfileId ? this.profileLoader.getProfile(this.state.activeProfileId) : null;
  }

  getState(){
    return JSON.parse(JSON.stringify(this.state));
  }

  getMetrics(profile){
    const nav = profile.navigator || {};
    const jumps = nav.jumps || {};
    const hold = nav.hold || {};
    const scroll = nav.scroll || {};
    const downThreshold = this.state.viewport.y + this.scaleY(scroll.downThreshold || 900);
    const upThreshold = this.state.viewport.y + this.scaleY(scroll.upThreshold || 150);
    return {
      horizontal: this.scaleX(jumps.horizontal || 240),
      row: this.scaleY(jumps.row || 180),
      bannerToRow: this.scaleY(jumps.bannerToRow || jumps.row || 180),
      holdStep: this.scaleX(hold.step || 10),
      holdStepY: this.scaleY(hold.stepY || hold.step || 10),
      scrollAmount: this.scaleY(scroll.amount || 340),
      downThreshold,
      upThreshold,
      topBrowseBandY: this.state.viewport.y + this.scaleY(180),
      bottomBrowseBandY: this.state.viewport.y + this.scaleY(760),
      browseBandY: Math.round((upThreshold + downThreshold) / 2)
    };
  }

  resolveAnchorPoint(profile){
    const anchor = profile.navigator?.anchor || { x: 960, y: 220 };
    const viewport = this.state.viewport;
    return {
      x: viewport.x + this.scaleX(anchor.x),
      y: viewport.y + this.scaleY(anchor.y)
    };
  }

  async moveToAnchor(profile=this.getProfile(), force=false){
    if(!profile) throw new Error('Navigator profile is not active.');
    this.clearIdleReturn();
    const point = this.resolveAnchorPoint(profile);
    this.state.anchor = { ...point, profileId: profile.id };
    this.state.laneX = point.x;
    this.state.currentZone = Number(profile.navigator?.initialZone || 0);
    this.state.topMode = force ? Boolean(profile.navigator?.topModeOnStart) : this.state.topMode;
    await this.adapter.moveMouseAbsolute(point.x, point.y);
    return point;
  }

  async setManualAnchor(){
    const profile = this.getProfile();
    if(!profile) throw new Error('Navigator profile is not active.');
    this.clearIdleReturn();
    const pos = await this.adapter.getMouseLocation();
    this.state.anchor = { x: pos.x, y: pos.y, profileId: profile.id };
    this.state.laneX = pos.x;
    this.state.currentZone = Number(profile.navigator?.initialZone || 0);
    return this.getState();
  }

  async recordFineMove(dx, dy){
    if(!this.state.enabled) throw new Error('Navigator is not enabled.');
    const profile = this.getProfile();
    const metrics = this.getMetrics(profile);
    const stepX = clamp(Math.round(dx), -1, 1) * metrics.holdStep;
    const stepY = clamp(Math.round(dy), -1, 1) * metrics.holdStepY;
    if(!stepX && !stepY) return this.getState();
    await this.adapter.moveMouseRelative(stepX, stepY);
    const pos = await this.adapter.getMouseLocation();
    this.state.laneX = pos.x;
    this.state.lastJump = { type: 'fine', x: pos.x, y: pos.y };
    return this.getState();
  }

  async jump(direction){
    if(!this.state.enabled) throw new Error('Navigator is not enabled.');
    const profile = this.getProfile();
    const metrics = this.getMetrics(profile);
    this.clearIdleReturn();
    const pos = await this.adapter.getMouseLocation();
    let nextX = pos.x;
    let nextY = pos.y;
    let idleReturnPoint = null;

    if(direction === 'left') nextX = pos.x - metrics.horizontal;
    else if(direction === 'right') nextX = pos.x + metrics.horizontal;
    else if(direction === 'down') {
      if(this.state.currentZone === 0 && this.state.topMode) {
        nextY = pos.y + metrics.bannerToRow;
        this.state.currentZone = 1;
      } else {
        nextY = pos.y + metrics.row;
        this.state.currentZone += 1;
      }
      nextX = this.state.laneX ?? pos.x;
      if(nextY >= metrics.downThreshold){
        await this.adapter.scrollVertical(Math.max(1, Math.round(metrics.scrollAmount / 120)));
        nextY = clamp(metrics.topBrowseBandY, this.state.viewport.y + this.scaleY(96), this.state.viewport.y + this.state.viewport.height - this.scaleY(160));
      }
    } else if(direction === 'up') {
      if(this.state.currentZone === 1 && this.state.topMode){
        nextY = pos.y - metrics.bannerToRow;
        this.state.currentZone = 0;
      } else {
        nextY = pos.y - metrics.row;
        this.state.currentZone = Math.max(0, this.state.currentZone - 1);
      }
      nextX = this.state.laneX ?? pos.x;
      if(nextY <= metrics.upThreshold && this.state.currentZone > 0){
        await this.adapter.scrollVertical(-Math.max(1, Math.round(metrics.scrollAmount / 120)));
        nextY = clamp(metrics.bottomBrowseBandY, this.state.viewport.y + this.scaleY(160), this.state.viewport.y + this.state.viewport.height - this.scaleY(96));
      }
    } else {
      throw new Error(`Unsupported navigator direction: ${direction}`);
    }

    const clamped = this.clampToViewport(nextX, nextY);
    if(direction === 'right'){
      idleReturnPoint = { x: clamped.x, y: clamped.y };
      const overshootX = clamp(clamped.x + this.scaleX(36), this.state.viewport.x + this.scaleX(32), this.state.viewport.x + this.state.viewport.width - this.scaleX(32));
      await this.adapter.moveMouseAbsolute(overshootX, clamped.y);
    }else{
      await this.adapter.moveMouseAbsolute(clamped.x, clamped.y);
    }
    if(direction === 'left' || direction === 'right') this.state.laneX = clamped.x;
    this.state.lastJump = { type: 'jump', direction, x: (direction === 'right' ? Math.min(clamped.x + this.scaleX(36), this.state.viewport.x + this.state.viewport.width - this.scaleX(32)) : clamped.x), y: clamped.y, zone: this.state.currentZone };
    if(idleReturnPoint) this.scheduleIdleReturn(idleReturnPoint);
    return this.getState();
  }

  clampToViewport(x, y){
    const v = this.state.viewport;
    const marginX = this.scaleX(32);
    const marginY = this.scaleY(24);
    return {
      x: clamp(Math.round(x), v.x + marginX, v.x + v.width - marginX),
      y: clamp(Math.round(y), v.y + marginY, v.y + v.height - marginY)
    };
  }
}

function readProfileFile(profilePath){
  return JSON.parse(fs.readFileSync(profilePath, 'utf8'));
}

class NavigatorProfileLoader {
  constructor(baseDir){
    this.baseDir = baseDir;
  }

  listProfiles(){
    const files = fs.readdirSync(this.baseDir).filter(name => name.endsWith('.json'));
    return files.map(name => readProfileFile(path.join(this.baseDir, name)));
  }

  getProfile(profileId){
    const filePath = path.join(this.baseDir, `${profileId}.json`);
    if(!fs.existsSync(filePath)) throw new Error(`Navigator profile not found: ${profileId}`);
    return readProfileFile(filePath);
  }
}

module.exports = { NavigatorCore, NavigatorProfileLoader };
