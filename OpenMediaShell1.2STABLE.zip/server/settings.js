const fs = require('fs');
const path = require('path');
const os = require('os');
const defaultsPath = path.join(__dirname, 'config', 'settings.default.json');
const runtimeDir = path.join(__dirname, 'data');
const runtimePath = path.join(runtimeDir, 'settings.json');
function ensureRuntimeFile(){
  if(!fs.existsSync(runtimeDir)) fs.mkdirSync(runtimeDir,{recursive:true});
  const defaults = JSON.parse(fs.readFileSync(defaultsPath,'utf8'));
  if(!fs.existsSync(runtimePath)){
    fs.writeFileSync(runtimePath, JSON.stringify(defaults,null,2));
    return defaults;
  }
  const current = JSON.parse(fs.readFileSync(runtimePath,'utf8'));
  const merged = {...defaults, ...current};
  fs.writeFileSync(runtimePath, JSON.stringify(merged,null,2));
  return merged;
}
function getSettings(){ return ensureRuntimeFile(); }
function saveSettings(next){ const merged = {...ensureRuntimeFile(), ...next}; fs.writeFileSync(runtimePath, JSON.stringify(merged,null,2)); return merged; }
function autostartDesktopPath(){ return path.join(os.homedir(), '.config', 'autostart', 'OpenTV.desktop'); }
function setAutostartEnabled(enabled){
  const file = autostartDesktopPath();
  if(!fs.existsSync(file)) return {ok:false,message:'Autostart file not found yet. Run the installer first.'};
  let text = fs.readFileSync(file,'utf8');
  text = /X-GNOME-Autostart-enabled=/i.test(text) ? text.replace(/X-GNOME-Autostart-enabled=.*/i, `X-GNOME-Autostart-enabled=${enabled?'true':'false'}`) : text + `\nX-GNOME-Autostart-enabled=${enabled?'true':'false'}`;
  text = /Hidden=/i.test(text) ? text.replace(/Hidden=.*/i, `Hidden=${enabled?'false':'true'}`) : text + `\nHidden=${enabled?'false':'true'}`;
  fs.writeFileSync(file, text);
  saveSettings({launchOnStartup:!!enabled});
  return {ok:true,message:`Launch on startup ${enabled?'enabled':'disabled'}.`};
}
module.exports = { getSettings, saveSettings, setAutostartEnabled };
