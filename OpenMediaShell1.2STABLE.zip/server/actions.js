const fs = require('fs');
const path = require('path');
const {
  sendKey,
  sendKeyCombo,
  mouseClick,
  moveMouseRelative,
  typeText,
  launchOrFocusAppProfile,
  getVolumePercent,
  volumeUp,
  volumeDown,
  volumeToggleMute,
  hideCursor,
  showCursor,
  closeAppsByProfiles,
  closeOpenTvUi,
  powerOffSystem
} = require('./adapters/x11');
const { getAppById, getClosableApps } = require('./apps/registry');
const { enableNavigatorProfile, disableNavigator, jumpNavigator } = require('./navigator');

const actions = JSON.parse(fs.readFileSync(path.join(__dirname,'config','actions.json'),'utf8'));
const state = {
  mode:'nav',
  selectedApp:null,
  volumePercent:null,
  isMuted:null,
  standby:false,
  cursorHidden:false,
  lastAction:null
};

async function refreshVolumeState(){
  try{
    const v=await getVolumePercent();
    state.volumePercent=v.percent;
    state.isMuted=v.isMuted;
  }catch{
    state.volumePercent=null;
    state.isMuted=null;
  }
}
function getState(){ return {...state}; }

async function launchApp(appId){
  const app = getAppById(appId);
  state.standby = false;
  state.selectedApp = app.id;
  state.mode = app.nativeArrowNavigation ? 'nav' : 'mouse';
  const result = await launchOrFocusAppProfile(app);
  if(app.nativeArrowNavigation) {
    disableNavigator();
  } else {
    await showCursor().catch(()=>{});
    state.cursorHidden = false;
    await enableNavigatorProfile(app);
  }
  return {
    ok:true,
    appId: app.id,
    action: app.name,
    message: result.focusedExisting ? `Focused ${app.name}.` : `Opened ${app.name}.`
  };
}

async function closeConfiguredApps(kind='standby'){
  const apps = getClosableApps().filter(app => kind === 'exit' ? app.closeOnExit : app.closeOnStandby);
  await closeAppsByProfiles(apps);
}

async function handleBackAction(){
  state.mode='nav';
  if(state.selectedApp === 'kodi'){
    await sendKey('BackSpace');
    return {ok:true,action:'Back',message:'Sent Kodi Back.'};
  }
  if(state.selectedApp){
    try{
      const app = getAppById(state.selectedApp);
      if(app.launch?.type === 'web'){
        await sendKeyCombo(['Alt+Left']);
        return {ok:true,action:'Back',message:'Sent browser Back.'};
      }
    }catch{}
  }
  await sendKey('Escape');
  return {ok:true,action:'Back',message:'Sent Escape.'};
}

async function handleClickAction(button='1'){
  state.standby=false;
  if(button === '3'){
    state.mode='mouse';
    await mouseClick('3');
    return {ok:true,action:'Right Click',message:'Sent right click.'};
  }

  let selectionMode = state.mode;
  if(state.selectedApp){
    try{
      const app = getAppById(state.selectedApp);
      if(app.selectAction === 'leftClick' || !app.nativeArrowNavigation) selectionMode = 'mouse';
      if(app.selectAction === 'enter' && app.nativeArrowNavigation) selectionMode = 'nav';
    }catch{}
  }

  if(selectionMode === 'mouse'){
    await mouseClick('1');
    return {ok:true,action:'Click',message:'Sent left click.'};
  }

  state.mode='nav';
  await sendKey('Return');
  return {ok:true,action:'Click',message:'Sent Enter.'};
}

async function handleCursorAction(value){
  if(value==='hide'){
    await hideCursor();
    state.cursorHidden=true;
    return {ok:true,action:'Hide Cursor',message:'Cursor hidden until the mouse moves.'};
  }
  if(value==='show'){
    await showCursor();
    state.cursorHidden=false;
    return {ok:true,action:'Show Cursor',message:'Cursor shown.'};
  }
  throw new Error(`Unknown cursor action: ${value}`);
}

async function handleMediaAction(value){
  state.mode='nav';
  state.standby=false;
  const keyMap = { play_pause:'XF86AudioPlay', next:'XF86AudioNext', previous:'XF86AudioPrev' };
  const key = keyMap[value];
  if(!key) throw new Error(`Unknown media action: ${value}`);
  await sendKey(key);
  return {ok:true,action:value,message:'Sent media control.'};
}

async function handleSystemAction(value, io){
  if(value==='standby'){
    state.standby=true;
    state.mode='nav';
    state.selectedApp=null;
    disableNavigator();
    try{ await closeConfiguredApps('standby'); }catch{}
    return {ok:true,action:'Standby',message:'Entered standby and closed apps marked for standby.'};
  }
  if(value==='wake'){
    state.standby=false;
    return {ok:true,action:'Wake',message:'Woke from standby.'};
  }
  if(value==='close_program'){
    state.standby=true;
    state.selectedApp=null;
    disableNavigator();
    try{ await closeConfiguredApps('exit'); }catch{}
    if(io){
      io.emit('server:result',{ok:true,action:'Close Program',message:'Closing OpenTV…'});
      io.emit('server:state',getState());
    }
    setTimeout(async()=>{
      try{ await showCursor(); }catch{}
      try{ await closeOpenTvUi(); }catch{}
      process.exit(0);
    },600);
    return {ok:true,action:'Close Program',message:'Closing OpenTV…'};
  }
  if(value==='power_off'){
    state.selectedApp=null;
    state.standby=true;
    disableNavigator();
    try{ await closeConfiguredApps('exit'); }catch{}
    setTimeout(async()=>{
      try{ await showCursor(); }catch{}
      try{ await powerOffSystem(); }catch{}
    },600);
    return {ok:true,action:'Power Off',message:'Powering off…'};
  }
  throw new Error(`Unknown system action: ${value}`);
}

async function handleVolumeAction(value){
  if(value==='up') await volumeUp();
  else if(value==='down') await volumeDown();
  else if(value==='mute') await volumeToggleMute();
  else throw new Error(`Unknown volume action: ${value}`);
  await refreshVolumeState();
  return {ok:true,action:value,message:`Volume ${state.volumePercent ?? '?'}%${state.isMuted?' (muted)':''}.`};
}

async function handleAction(actionName,{io}={}){
  state.lastAction=actionName;
  if(actionName==='Back') return handleBackAction();
  if(actionName==='Click') return handleClickAction();
  if(actionName==='Right Click') return handleClickAction('3');

  if(['Up','Down','Left','Right'].includes(actionName) && state.selectedApp){
    try{
      const app = getAppById(state.selectedApp);
      if(app && app.nativeArrowNavigation === false){
        const directionMap = { Up:'up', Down:'down', Left:'left', Right:'right' };
        const navState = await jumpNavigator(directionMap[actionName]);
        state.mode = 'mouse';
        state.standby = false;
        return { ok:true, action:actionName, message:`Navigator moved ${directionMap[actionName]}.`, navigator: navState };
      }
    }catch{}
  }

  const entry=actions[actionName];
  if(!entry) throw new Error(`Unknown action: ${actionName}`);
  switch(entry.type){
    case 'key':
      state.mode='nav';
      state.standby=false;
      await sendKey(entry.value);
      return {ok:true,action:actionName,message:`Sent key: ${entry.value}`};
    case 'click':
      return handleClickAction(entry.value);
    case 'mode':
      state.mode=entry.value;
      return {ok:true,action:actionName,message:`Switched to ${entry.value} mode.`};
    case 'volume':
      state.mode='nav';
      return handleVolumeAction(entry.value);
    case 'system':
      return handleSystemAction(entry.value, io);
    case 'cursor':
      return handleCursorAction(entry.value);
    case 'media':
      return handleMediaAction(entry.value);
    default:
      throw new Error(`Unsupported action type: ${entry.type}`);
  }
}

async function handleMouseMove(dx,dy){
  state.mode='mouse';
  state.standby=false;
  await moveMouseRelative(Math.max(-80,Math.min(80,Math.round(dx))),Math.max(-80,Math.min(80,Math.round(dy))));
  return {ok:true,message:'Mouse moved.'};
}
async function handleTextInput(text, submit){
  state.mode='keyboard';
  state.standby=false;
  if(text) await typeText(text);
  if(submit) await sendKey('Return');
  return {ok:true,message: submit ? 'Typed text and pressed Enter.' : 'Typed text.'};
}

(async()=>{ await refreshVolumeState(); })();
process.on('exit', ()=>{ showCursor().catch(()=>{}); });
process.on('SIGINT', ()=>{ showCursor().catch(()=>{}); process.exit(0); });
process.on('SIGTERM', ()=>{ showCursor().catch(()=>{}); process.exit(0); });

module.exports = { handleAction, handleMouseMove, handleTextInput, getState, launchApp };
