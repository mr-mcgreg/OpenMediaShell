const { execFile, exec } = require('child_process');
const os = require('os');

function execFileAsync(file,args=[]){ return new Promise((resolve,reject)=>execFile(file,args,(e,stdout,stderr)=>e?reject(new Error((stderr||e.message).trim())):resolve({stdout:(stdout||'').trim(),stderr:(stderr||'').trim()}))); }
function execShellAsync(cmd){ return new Promise((resolve,reject)=>exec(cmd,(e,stdout,stderr)=>e?reject(new Error((stderr||e.message).trim())):resolve({stdout:(stdout||'').trim(),stderr:(stderr||'').trim()}))); }
async function commandExists(name){ try{ await execShellAsync(`command -v ${name}`); return true; }catch{return false;} }
function sleep(ms){ return new Promise(resolve=>setTimeout(resolve,ms)); }

async function sendKey(key){ await execFileAsync('xdotool',['key',key]); }
async function sendKeyCombo(keys){ await execFileAsync('xdotool',['key',...keys]); }
async function mouseClick(button='1'){ await execFileAsync('xdotool',['click',String(button)]); }
async function moveMouseRelative(dx,dy){ await execFileAsync('xdotool',['mousemove_relative','--',String(dx),String(dy)]); }
async function moveMouseAbsolute(x,y){ await execFileAsync('xdotool',['mousemove',String(x),String(y)]); }
async function typeText(text){ await execFileAsync('xdotool',['type','--delay','1',text]); }
async function searchWindowIds(name){ try{ const {stdout}=await execFileAsync('xdotool',['search','--name',name]); return stdout.split(/\s+/).filter(Boolean);}catch{return [];} }

async function getMouseLocation(){
  const {stdout}=await execFileAsync('xdotool',['getmouselocation','--shell']);
  const values={};
  stdout.split(/\n+/).forEach(line=>{
    const [key, value] = line.split('=');
    if(key) values[key.trim()] = value?.trim();
  });
  return { x:Number(values.X||0), y:Number(values.Y||0), screen:Number(values.SCREEN||0), windowId:values.WINDOW||null };
}
async function scrollVertical(clicks){
  const amount = Number(clicks||0);
  if(!amount) return;
  const button = amount > 0 ? '5' : '4';
  for(let i=0;i<Math.abs(amount);i++) await mouseClick(button);
}
async function getDisplayInfo(){
  if(await commandExists('xrandr')){
    try{
      const {stdout}=await execFileAsync('xrandr',['--current']);
      const m=stdout.match(/current\s+(\d+)\s+x\s+(\d+)/i);
      if(m) return {width:Number(m[1]), height:Number(m[2]), source:'xrandr'};
    }catch{}
  }
  try{
    const {stdout}=await execFileAsync('xdotool',['getdisplaygeometry']);
    const m=stdout.match(/(\d+)\s+(\d+)/);
    if(m) return {width:Number(m[1]), height:Number(m[2]), source:'xdotool'};
  }catch{}
  return {width:1920, height:1080, source:'fallback'};
}

async function getActiveWindowId(){ try{ const {stdout}=await execFileAsync('xdotool',['getactivewindow']); return stdout.trim(); }catch{return null;} }
async function getWindowName(id){ try{ const {stdout}=await execFileAsync('xdotool',['getwindowname',String(id)]); return stdout.trim(); }catch{return ''; } }
async function focusWindowId(id){ await execFileAsync('xdotool',['windowactivate','--sync',String(id)]); }
async function focusWindowByName(name){ const ids=await searchWindowIds(name); if(!ids.length) return false; await focusWindowId(ids[ids.length-1]); return true; }
async function isWindowFullscreen(id){
  if(!(await commandExists('xprop'))) return false;
  try{
    const {stdout}=await execFileAsync('xprop',['-id',String(id),'_NET_WM_STATE']);
    return stdout.includes('_NET_WM_STATE_FULLSCREEN');
  }catch{return false;}
}
async function ensureWindowFullscreen(id){
  if(!id) return false;
  if(await isWindowFullscreen(id)) return true;
  await focusWindowId(id);
  await sleep(250);
  await execFileAsync('xdotool',['key','F11']);
  return true;
}
async function launchDetached(command){ await execShellAsync(`nohup bash -lc '${command}' >/dev/null 2>&1 &`); }
async function chromeBinary(){ for(const c of ['google-chrome','google-chrome-stable','chromium-browser','chromium']) if(await commandExists(c)) return c; throw new Error('Could not find Chrome or Chromium on this system.'); }

async function findNewestWindow(patterns=[]){
  for(const pattern of patterns){
    const ids = await searchWindowIds(pattern);
    if(ids.length) return ids[ids.length-1];
  }
  return null;
}

async function openOrFocusWebApp(appName, url, options={}){
  const focusKick=options.focusKick||null;
  const searchPatterns = Array.isArray(options.searchPatterns) && options.searchPatterns.length ? options.searchPatterns : [appName, `${appName} - Google Chrome`, `${appName} - Chromium`, `${appName} — Google Chrome`, `${appName} — Chromium`];
  let targetId = await findNewestWindow(searchPatterns);

  if(targetId){
    await focusWindowId(targetId);
    await sleep(250);
    await ensureWindowFullscreen(targetId);
    if(focusKick) setTimeout(()=>execFile('xdotool',['key',focusKick],()=>{}),500);
    return {focusedExisting:true};
  }

  const bin=await chromeBinary();
  await launchDetached(`${bin} --new-window --new-tab "${url}"`);

  for(let i=0;i<12;i++){
    await sleep(500);
    targetId = await findNewestWindow(searchPatterns);
    if(targetId) break;
  }
  if(targetId){
    await focusWindowId(targetId);
    await sleep(300);
    await ensureWindowFullscreen(targetId);
    if(focusKick) setTimeout(()=>execFile('xdotool',['key',focusKick],()=>{}),600);
  }
  return {focusedExisting:false};
}


async function launchOrFocusAppProfile(app){
  const patterns = Array.isArray(app.windowMatch) && app.windowMatch.length ? app.windowMatch : [app.name];
  if(app.launch?.type === 'desktop') {
    let targetId = await findNewestWindow(patterns);
    if(targetId){
      await focusWindowId(targetId);
      await sleep(250);
      if(app.fullscreen !== false) await ensureWindowFullscreen(targetId);
      return {focusedExisting:true, windowId:targetId};
    }
    const command = app.launch?.command;
    if(!command) throw new Error(`App profile ${app.id} is missing launch.command.`);
    await launchDetached(command);
    for(let i=0;i<16;i++){
      await sleep(500);
      targetId = await findNewestWindow(patterns);
      if(targetId) break;
    }
    if(targetId){
      await focusWindowId(targetId);
      await sleep(250);
      if(app.fullscreen !== false) await ensureWindowFullscreen(targetId);
    }
    return {focusedExisting:false, windowId:targetId};
  }

  return openOrFocusWebApp(app.name, app.launch?.url, {
    searchPatterns: patterns,
    focusKick: app.launch?.focusKick || null
  });
}

async function closeAppsByProfiles(apps=[]){
  const patterns = [];
  const commands = [];
  for(const app of apps){
    for(const pattern of (app.windowMatch || [])) patterns.push(pattern);
    if(app.launch?.type === 'desktop' && app.launch?.command) {
      const cmd = String(app.launch.command).trim().split(/\s+/)[0];
      if(cmd) commands.push(cmd);
    }
    if(app.launch?.type === 'web' && app.launch?.url){
      try{
        const host = new URL(app.launch.url).hostname.replace(/^www\./,'').replace(/\./g,'\.');
        commands.push(host);
      }catch{}
    }
  }
  await closeWindowsByPatterns(patterns);
  for(const target of commands){
    try{ await execShellAsync(`pkill -f '${target}'`); }catch{}
  }
}

async function launchKodi(){
  let targetId = await findNewestWindow(['Kodi']);
  if(targetId){
    await focusWindowId(targetId);
    await sleep(250);
    await ensureWindowFullscreen(targetId);
    return {focusedExisting:true};
  }
  if(!(await commandExists('kodi'))) throw new Error('Kodi is not installed or not in PATH.');
  await launchDetached('kodi');
  for(let i=0;i<16;i++){
    await sleep(500);
    targetId = await findNewestWindow(['Kodi']);
    if(targetId) break;
  }
  if(targetId){
    await focusWindowId(targetId);
    await sleep(300);
    await ensureWindowFullscreen(targetId);
  }
  return {focusedExisting:false};
}

async function readVolumeViaWpctl(){
  const {stdout}=await execFileAsync('wpctl',['get-volume','@DEFAULT_AUDIO_SINK@']);
  const isMuted=/\[MUTED\]/i.test(stdout);
  const m=stdout.match(/([0-9]*\.?[0-9]+)/);
  if(!m) throw new Error(`Could not parse volume from: ${stdout}`);
  return {percent:Math.round(Number(m[1])*100), isMuted};
}
async function readVolumeViaPactl(){
  const {stdout}=await execFileAsync('pactl',['get-sink-volume','@DEFAULT_SINK@']);
  const m=stdout.match(/(\d+)%/);
  if(!m) throw new Error(`Could not parse pactl volume from: ${stdout}`);
  let mutedOut='';
  try{ mutedOut=(await execFileAsync('pactl',['get-sink-mute','@DEFAULT_SINK@'])).stdout; }catch{}
  return {percent:Number(m[1]), isMuted:/yes/i.test(mutedOut)};
}
async function readVolumeViaAmixer(){
  const {stdout}=await execFileAsync('amixer',['get','Master']);
  const matches=[...stdout.matchAll(/\[(\d+)%\]/g)];
  if(!matches.length) throw new Error(`Could not parse amixer volume from: ${stdout}`);
  const muteMatches=[...stdout.matchAll(/\[(on|off)\]/gi)];
  const lastMute=muteMatches.length ? muteMatches[muteMatches.length-1][1].toLowerCase() : 'on';
  return {percent:Number(matches[matches.length-1][1]), isMuted:lastMute==='off'};
}
async function getVolumePercent(){
  if(await commandExists('wpctl')){ try{return await readVolumeViaWpctl();}catch{} }
  if(await commandExists('pactl')){ try{return await readVolumeViaPactl();}catch{} }
  if(await commandExists('amixer')) return readVolumeViaAmixer();
  throw new Error('No supported volume control tool found.');
}
async function volumeUp(){
  if(await commandExists('wpctl')){ try{ await execFileAsync('wpctl',['set-volume','-l','1.5','@DEFAULT_AUDIO_SINK@','5%+']); return; }catch{} }
  if(await commandExists('pactl')){ try{ await execFileAsync('pactl',['set-sink-volume','@DEFAULT_SINK@','+5%']); return; }catch{} }
  if(await commandExists('amixer')){ try{ await execFileAsync('amixer',['-D','pulse','sset','Master','5%+']); return; }catch{} try{ await execFileAsync('amixer',['sset','Master','5%+']); return; }catch{} }
  await sendKey('XF86AudioRaiseVolume');
}
async function volumeDown(){
  if(await commandExists('wpctl')){ try{ await execFileAsync('wpctl',['set-volume','@DEFAULT_AUDIO_SINK@','5%-']); return; }catch{} }
  if(await commandExists('pactl')){ try{ await execFileAsync('pactl',['set-sink-volume','@DEFAULT_SINK@','-5%']); return; }catch{} }
  if(await commandExists('amixer')){ try{ await execFileAsync('amixer',['-D','pulse','sset','Master','5%-']); return; }catch{} try{ await execFileAsync('amixer',['sset','Master','5%-']); return; }catch{} }
  await sendKey('XF86AudioLowerVolume');
}
async function volumeToggleMute(){
  if(await commandExists('wpctl')){ try{ await execFileAsync('wpctl',['set-mute','@DEFAULT_AUDIO_SINK@','toggle']); return; }catch{} }
  if(await commandExists('pactl')){ try{ await execFileAsync('pactl',['set-sink-mute','@DEFAULT_SINK@','toggle']); return; }catch{} }
  if(await commandExists('amixer')){ try{ await execFileAsync('amixer',['-D','pulse','sset','Master','toggle']); return; }catch{} try{ await execFileAsync('amixer',['sset','Master','toggle']); return; }catch{} }
  await sendKey('XF86AudioMute');
}

async function closeWindowById(id){
  try{ await execFileAsync('xdotool',['windowclose',String(id)]); return true; }catch{return false;}
}
async function closeWindowsByPatterns(patterns=[]){
  const seen=new Set();
  for(const pattern of patterns){
    const ids=await searchWindowIds(pattern);
    for(const id of ids){
      if(seen.has(id)) continue;
      seen.add(id);
      await closeWindowById(id);
    }
  }
  return seen.size;
}
async function closeManagedApps(){
  await closeWindowsByPatterns([
    'Netflix',
    'YouTube',
    'Kodi',
    'Kodi Media Center'
  ]);
  for(const cmd of [
    "pkill -f 'kodi'",
    "pkill -f 'youtube\.com'",
    "pkill -f 'netflix\.com'"
  ]){ try{ await execShellAsync(cmd); }catch{} }
}

async function hideCursor(){
  if(!(await commandExists('unclutter'))) throw new Error('unclutter is not installed. Re-run the installer to add cursor hiding support.');
  try{ await execShellAsync('pkill -x unclutter'); }catch{}
  // Different distros package different unclutter variants; try the classic flags first, then fallback.
  try{ await launchDetached('unclutter -idle 0 -root'); }
  catch{ await launchDetached('unclutter --timeout 0 --jitter 1'); }
  await sleep(250);
}
async function showCursor(){ try{ await execShellAsync('pkill -x unclutter'); }catch{} }

async function closeOpenTvUi(){
  for(const cmd of [
    "pkill -f 'chromium.*127.0.0.1:3000'",
    "pkill -f 'chromium-browser.*127.0.0.1:3000'",
    "pkill -f 'google-chrome.*127.0.0.1:3000'",
    "pkill -x unclutter"
  ]){ try{ await execShellAsync(cmd);}catch{} }
}
async function powerOffSystem(){ for(const cmd of ['systemctl poweroff','shutdown now']){ try{ await execShellAsync(cmd); return; }catch{} } throw new Error('Could not power off the system.'); }
async function pickFolder(){
  if(await commandExists('zenity')){ const {stdout}=await execFileAsync('zenity',['--file-selection','--directory','--title=Select OpenTV Background Folder']); return stdout.trim(); }
  if(await commandExists('kdialog')){ const {stdout}=await execFileAsync('kdialog',['--getexistingdirectory',os.homedir(),'--title','Select OpenTV Background Folder']); return stdout.trim(); }
  throw new Error('No folder picker found. Install zenity or kdialog, or enter the folder path manually.');
}

module.exports = {
  sendKey,
  sendKeyCombo,
  mouseClick,
  moveMouseRelative,
  moveMouseAbsolute,
  typeText,
  getMouseLocation,
  scrollVertical,
  getDisplayInfo,
  getActiveWindowId,
  getWindowName,
  ensureWindowFullscreen,
  openOrFocusWebApp,
  launchOrFocusAppProfile,
  closeAppsByProfiles,
  launchKodi,
  getVolumePercent,
  volumeUp,
  volumeDown,
  volumeToggleMute,
  hideCursor,
  showCursor,
  closeManagedApps,
  closeOpenTvUi,
  powerOffSystem,
  pickFolder
};
