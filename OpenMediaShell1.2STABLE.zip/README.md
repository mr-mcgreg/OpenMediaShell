# OpenTV 1.0

OpenTV 1.0 is a modular remote-first launcher for Chrome-based streaming apps and Kodi on Linux.

## What changed in 1.0
- One JSON file per app under `server/apps/profiles/`
- TV home screen builds itself from app profiles
- Remote quick-launch buttons build themselves from app profiles
- Launch, focus, fullscreen, and close behavior come from app profiles
- Chrome/Chromium is used for web streaming apps for DRM support
- Navigator data lives inside the same app profile file
- Includes a reusable AI prompt at `APP_PROFILE_PROMPT.md`

## Built-in example app profiles
- `netflix.json`
- `youtube.json`
- `kodi.json`
- `_template.json` for creating new apps

## App profile location
`server/apps/profiles/`

## Add your own app
1. Copy `_template.json`
2. Rename it, for example `hulu.json`
3. Fill in the fields without changing the schema
4. Add the icon file under `client/assets/icons/`
5. Restart OpenTV

## Install
```bash
chmod +x install_opentv.sh
./install_opentv.sh
```

## Notes
- Web apps launch in Chrome/Chromium
- Kodi remains a desktop app
- The installer still installs only the main base dependencies plus Chrome/Chromium and Kodi
- The installed launcher now starts the Node server directly instead of `npm start`
