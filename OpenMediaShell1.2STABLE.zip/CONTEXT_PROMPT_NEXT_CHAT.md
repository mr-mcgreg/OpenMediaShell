Project: OpenTV
Current release baseline: Published_Release_V1.0 patched for kiosk launcher behavior and updated built-in streaming profiles.

Important persistent requirements:
- npm/node processes must fully stop when the app closes
- OpenTV should feel like a polished TV OS shell, not just a plain browser tab
- Main shell should launch in Chrome/Chromium fullscreen style, currently via kiosk mode rather than app mode

Current working state:
- one-file-per-app JSON profile system
- Netflix smart-nav works through navigator API
- Remote arrows were patched to call navigator jump/nudge for smart-nav apps
- Launcher now should open the main TV shell in Chrome kiosk mode with URL /tv
- Built-in SVG icons are present for Netflix, YouTube, and Kodi

Known tuning areas after this release:
- YouTube smart-nav may still need profile tuning depending on the exact desktop layout shown
- Netflix row/banner jump sizes may still need small percentage adjustments after testing
- Launcher/fullscreen polish should be validated on the target Linux setup

Files most relevant next:
- server/apps/profiles/netflix.json
- server/apps/profiles/youtube.json
- client/remote/index.html
- server/actions.js
- install_opentv.sh

Do not restart from scratch. Continue from this packaged release.


Latest patch notes:
- Remote circular pad layout moved mute near the D-pad and back beside the left arrow with no overlap.
- Built-in YouTube profile retuned with larger jumps and a better anchor for controller navigation.
